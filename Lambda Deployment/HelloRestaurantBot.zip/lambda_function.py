def lambda_handler(event, context):
    # TODO implement
    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": "Hello I am RestaurantBot and I can help you find restaurants and reviews for restaurants in any city."
            }
        }
    }
