
def lambda_handler(event, context):
    # TODO implement
    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": "Hello I am RestaurantBot and I can help you find restaurants, first let me know if you want to find a restaurant and then tell me what type of restaurant you are looking for."
            }
        }
    }